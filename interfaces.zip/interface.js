const myInterface = Symbol('myInterface');
 
export default myInterface;