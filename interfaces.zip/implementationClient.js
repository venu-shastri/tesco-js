import myInterface from 'myInterface';
import Foo from 'foo';

function doInc(obj){
  const interface = obj[myInterface];

  if (interface === undefined) {
    throw new Error('Object does not support the interface.');
  }
  interface.inc();
}

const counter = new Foo(0);

doInc(counter);