In order to get started with this repo, please follow the steps below:

- Start by navigating to the directory of this code in your terminal / command prompt
- Run npm install (or yarn) in your terminal to install the dependencies
- Next, start up the application by typing node server.js in your terminal / command prompt
- Finally, navigate to http://localhost:3111 in your browser and start receiving notifications!