"use strict";


module.exports = (db, tokenSecret) => {
  
  const authService = {};
  
  authService.login = (username, password, callback) => {
  
        
        callback(null, tokenSecret);
      };
    
  

  
  return authService;
};
