"use strict";

module.exports = (authService) => {
  const authController = {};
  
  authController.login = (username,password) => {
    authService.login(username,password,
      (err, result) => {
        if (err) {
          return{
            ok: false,
            error: 'Invalid username/password'
          };
        }
        return {ok: true, token: result};
      }
    );
  };

  
  return authController;
};
