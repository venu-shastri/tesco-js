"use strict";


module.exports = (dbName) => {
  return {dbName:dbName};
  
};
