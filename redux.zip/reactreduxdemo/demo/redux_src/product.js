import React,{Component} from 'react'
export class ProductRowComponent extends Component{

    render(){
        return(
                <tr>
                    <td>{this.props.product.Id}</td>
                    <td>{this.props.product.Name}</td>
                    </tr>
        );
    }
}