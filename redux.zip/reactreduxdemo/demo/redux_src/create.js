import React,{Component} from 'react'
export class CreateProductComponent extends Component{

    newProduct={};
    constructor(props){
        super(props);
        this.handleButtonClick=this.handleButtonClick.bind(this);
        this.handleIDTextChange=this.handleIDTextChange.bind(this);
        this.handleNameTextChange=this.handleNameTextChange.bind(this);

    }
    handleIDTextChange(e){this.newProduct.Id=e.target.value;}
    handleNameTextChange(e){this.newProduct.Name=e.target.value;}
    handleButtonClick(){
        this.props.onNewButtonClick(this.newProduct);
    }
    render(){
        return(
            <div>
                    <p>Product Id <input type="text" onChange={this.handleIDTextChange}/></p>
                    <p>Product Name <input type="text" onChange={this.handleNameTextChange}/></p>
                    <p><button onClick={this.handleButtonClick} >AddNewProduct</button></p>
            </div>
        );
    }
}