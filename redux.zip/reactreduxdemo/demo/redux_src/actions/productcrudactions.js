export const createNewProductAction=function(newProduct){
return {
    type:"ADD_NEW_PRODUCT",
    PayLoad:newProduct
}
    
};

export const getCurrentProductsAction=function(newProduct){
    return {
        type:"GET_CURRENT_PRODUCTS",

    }
        
    };
    


