import {createStore} from 'redux';
import {productReducer} from '../reducers/productreducer'
var productStore=createStore(productReducer);

export default productStore;