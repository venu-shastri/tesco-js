export function productReducer(products=[],action){

    if(action.type==="ADD_NEW_PRODUCT"){

        return products.concat(action.PayLoad);
    }

    if(action.type==="GET_CURRENT_PRODUCTS"){
        return products;
    }


    return products;
}