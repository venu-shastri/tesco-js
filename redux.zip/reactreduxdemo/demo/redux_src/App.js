import React,{Component} from 'react'
import productStore from './store/productStore'
import {ViewComponent} from './view'
import {CreateProductComponent} from './create'
import {createNewProductAction} from './actions/productcrudactions'
export class AppComponent extends Component{

    constructor(props){
        super(props);
        this.state={productsList:[]};
        this.handleNewProductCreated=this.handleNewProductCreated.bind(this);
        this.handleOnNewButtonClick=this.handleOnNewButtonClick.bind(this);
      

    }
    componentDidMount(){
  productStore.subscribe(this.handleNewProductCreated);
    }
    handleNewProductCreated(){
            var products=productStore.getState();
            this.setState({productsList:products});
    }
    handleOnNewButtonClick(payLoad){
      var action=createNewProductAction(payLoad);
      console.log(action);
    productStore.dispatch(action); 
    console.log(payLoad);
    }
    render(){
        return(
                <div>
                  <ViewComponent products={this.state.productsList}/>
                    <CreateProductComponent onNewButtonClick={this.handleOnNewButtonClick}/>
                </div>
        );
    }
}
