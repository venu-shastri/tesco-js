import React,{Component} from 'react'
import {ProductRowComponent} from './product'
export class ViewComponent extends Component{

    constructor(props){
        super(props);

    }
    render(){
        var rows=[];
        this.props.products.forEach(product => {

         rows.push(<ProductRowComponent key={product.Id} product={product}/>);
            
        });
        return(
        <table>
            <tbody>
                {rows}
            </tbody>
     </table>   
        );
    }
}