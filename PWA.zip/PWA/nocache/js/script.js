if (window.console) {
  console.log('This script is not cached');
}
