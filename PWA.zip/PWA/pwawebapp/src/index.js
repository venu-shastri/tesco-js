import React from "react";
import ReactDOM from "react-dom";

 //import FormContainer from "./js/components/container/formContainer.jsx"
 import {App} from './js/components/App'
const wrapper = document.getElementById("create-article-form");
wrapper ? ReactDOM.render(<FormContainer />, wrapper) : false;