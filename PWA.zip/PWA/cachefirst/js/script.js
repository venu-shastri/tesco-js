if (window.console) {
  console.log('Hello Service Worker caching!');
}
